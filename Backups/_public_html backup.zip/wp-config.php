<?php
define( 'WP_CACHE', true );

/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * Localized language
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'u899426639_iXSq1' );

/** Database username */
define( 'DB_USER', 'u899426639_PrYTb' );

/** Database password */
define( 'DB_PASSWORD', 'ZicsWbRTAG' );

/** Database hostname */
define( 'DB_HOST', '127.0.0.1' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          'G:kt9}M`B2g#^r5zxe%RouOV*91`0<s7{$}T}y5kCy2=Tv6eT^ZU[%|Wne@N~g?m' );
define( 'SECURE_AUTH_KEY',   'kaR$ife(H56:-ak)@Dd8 1(<`mDs`H<#BIZ~Xj|&gsJ4d2k8OIG/7a#A80$T<R2W' );
define( 'LOGGED_IN_KEY',     'PB/A7VZ_2MT9:0!3M+>t/ |fvPm?$<x:d;D0J0UQvC{g-Ys(e-9H]Eh60vD`d*@S' );
define( 'NONCE_KEY',         '/*6Ar(~.|M9nC%//hzV2&!z}g|yURZW-m=N$s:^QH8-Oo,_MoW#/F,#yJ$Q7sEn!' );
define( 'AUTH_SALT',         '@4V ae_^k%8_5gnpVMJdHQ~KCp0w VrQ`]~O/HA_y8b?K57d./<_F>mwem@iN/3>' );
define( 'SECURE_AUTH_SALT',  '=4f2I{u&Elc)9/~vgR)<CTqVzL<q=IuDLJt>7]4/ Y(*d@o/?8!g2ds|tXlKYi6j' );
define( 'LOGGED_IN_SALT',    'q5 351-SX(C>DR4_IF~R$QF)-I&Hp6z|]YFF95,{E<!e22<m.VR*g&qTGdzMa6g}' );
define( 'NONCE_SALT',        '4:75%l;7MqR0VCj`)X~US}i6i,o{6K<~6(-{K?yOmk>nuj`jK9_,h|y4UAIj.iMv' );
define( 'WP_CACHE_KEY_SALT', 'KMeyYlLwNWCD*s|4`qNXu9Z%f-!AfMbjHhC`bC!|,qF*$mn@q4K**#PH#!|m ?jU' );


/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';


/* Add any custom values between this line and the "stop editing" line. */



/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
if ( ! defined( 'WP_DEBUG' ) ) {
	define( 'WP_DEBUG', false );
}

define( 'FS_METHOD', 'direct' );
define( 'COOKIEHASH', '7f35df9e4a7f7d7f8bc5b3442b9484b2' );
define( 'WP_AUTO_UPDATE_CORE', 'minor' );
/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
